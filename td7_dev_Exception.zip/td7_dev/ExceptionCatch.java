class ExceptionCatch 
{ 
static int moyenne(String[] liste)  
  { 
int somme = 0,entier, nbNotes = 0; 
for (int i = 0; i < liste.length;i++)  
      { 
try 
  {      
    entier = Integer.parseInt(liste[i]);
    somme += entier; 
    nbNotes++; 
  } 
catch (NumberFormatException e) 
  { 
    System.out.println("La "+(i+1)+" eme note "+ 
                       "n'est pas entiere"); 
  } 
      } 
return somme/nbNotes
 ; 
  } 
public static void main(String[] argv) 
  { 
    System.out. println("La moyenne est " + moyenne(argv)); 
  } 
} 

// pour cette input java ExceptionCatch 
// Exception in thread "main" java.lang.ArithmeticException: / by zero


// alors que pour java ExceptionCatch ha 15 12  
// La 1 eme note n'est pas entiere
// La moyenne est 13


// tandisque pour celle ci :  java ExceptionCatch ha 15.5 
// La 1 eme note n'est pas entiere
// La 2 eme note n'est pas entiere
// Exception in thread "main" java.lang.ArithmeticException: / by zero


class ExceptionRien extends Exception  
{ 
  ExceptionRien() 
    { 
      System.out.println("Une ExceptionRien s'est produite"); 
    } 
public String toString() 
  { 
return "Aucune note n'est valide"; 
  } 
} 
class ExceptionThrow 
{ 
static int moyenne(String[] liste) throws ExceptionRien
  { 
int somme=0,entier, nbNotes=0; 
int i; 
for (i=0;i < liste.length;i++)  
      { 
try 
  {      
    entier=Integer.parseInt(liste[i]); 
    somme+=entier; 
    nbNotes++; 
  } 
catch (NumberFormatException e) 
  { 
    System.out.println("La "+(i+1)+" eme note n'est "+ 
       "pas entiere"); 
  } 
      } 
if (nbNotes==0) throw new ExceptionRien()
 ; 
return somme/nbNotes; 
  } 
public static void main(String[] argv) 
  { 
try 
      { 
System.out.println("La moyenne est "+moyenne(argv)); 
      } 
catch (ExceptionRien e)    
      { 
System.out.println(e); 
      } 
  } 
}

// on obtient rien ==> Error: Could not find or load main class ExceptionThrows
class UtiliseFinally 
{ 
static int moyenne(String[] liste) 
  { 
int somme=0,entier, nbNotes=0; 
    int i=0; 
for (i=0;i < liste.length;i++)  
      { 
try 
  {      

    entier=Integer.parseInt(liste[i]); 
    somme+=entier; 
    nbNotes++; 
  }
finally 
  { 
    System.out.println("donnee traitee : "+liste[i]); 
      } 
    }
return somme/nbNotes; 
  } 
public static void main(String[] argv) 
  { 
try 
      { 
System.out. println("La moyenne est "+moyenne(argv)); 
      } 
catch (NumberFormatException e)   
      { 
System.out.println("Erreur sur vos entiers"); 
      }  
  } 
} 
// output:
// donnee traitee : 15
// donnee traitee : 14
// donnee traitee : ha
// Erreur sur vos entiers