import java.io.*; 
 import java.util.*; 
class SaisieClavier { 
  public static void main (String[] argv) throws IOException,  
               NumberFormatException  
  { 
    int somme = 0; 
    String ligne; 
    StringTokenizer st;  
    BufferedReader entree = new BufferedReader 
      (new InputStreamReader(System.in)); 
  
    ligne = entree.readLine(); 
    while(ligne.length() > 0) 
      { 
 st = new StringTokenizer(ligne); 
 while(st.hasMoreTokens()) 
   somme += Integer.parseInt(st.nextToken()); 
 ligne = entree.readLine(); 
      } 
    System.out.println("La somme vaut : "+somme); 
  } 
} 


// a-1)La classe InputStreamReader est une classe qui nour aide a lire les donne d entre elle les convertis en octes via le flux d entre tandisque la classe StringTokenizer permet de decouper la chaine de caractere en tokens en utulisant des delimiteur par default l espace .
