import java.io.*;

public class SegmentDeserializable {
    public static void main(String[] args) throws Exception {
        ObjectInputStream x = new ObjectInputStream(new FileInputStream("segment.ser"));
        Segment seg1 = (Segment) x.readObject();
        Segment seg2 = (Segment) x.readObject();

        seg1.Afficher();
        seg2.Afficher();
        x.close();

    }
}
