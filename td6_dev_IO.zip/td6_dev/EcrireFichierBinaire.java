import java.io.*; 

class EcrireFichierBinaire { 
  public static void main(String[] argv) throws IOException  
  { 
    DataOutputStream ecrivain; 
    ecrivain =   
      new DataOutputStream(new BufferedOutputStream 
      (new FileOutputStream(argv[0]))); 
    ecrivain.writeUTF("bonjour"); 
    ecrivain.writeInt(3); 
    ecrivain.writeLong(100000); 
    ecrivain.writeFloat((float)2.0); 
    ecrivain.writeDouble(3.5); 
    ecrivain.writeChar('a'); 
    ecrivain.writeBoolean(false);  
    ecrivain.writeUTF("au revoir"); 
    System.out.println(ecrivain.size()); 
    ecrivain.close(); 
  }

  } 

    // 1.1- Dans ce code apres l execution on obtient une erreur , et cette erreu s est produit car on n a pas donner au flux de sortie la fichier binaire ou il doit stocker les informations.
    // 1.2- Le fichier resultat contient les string comme ils sont mais les autre type il sont en binaire.
    // 1.3- Il faut utuliser la classe DataInputStream et les methode read<type> pour lire les contenues du fichier.
    