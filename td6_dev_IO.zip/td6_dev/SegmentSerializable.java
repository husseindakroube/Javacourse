import java.io.*;


public class SegmentSerializable{
    public static void main(String[] args) throws IOException{
        Segment seg1 = new Segment(0,0,0,5);
        Segment seg2 = new Segment(3,4,5,6);
        ObjectOutputStream x = new ObjectOutputStream(new FileOutputStream("segment.ser"));
        x.writeObject(seg1);
        x.writeObject(seg2);
        x.close();
    }
}