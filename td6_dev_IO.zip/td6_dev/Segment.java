import java.io.*;

public class Segment implements Serializable {
    private double abscisse_debut;
    private double abscisse_fin ;
    private double ordonnee_debut;
    private double ordonnee_fin;
    public Segment(double abscisse_debut_, double ordonnee_debut_, double abscisse_fin_, double ordonnee_fin_) {
        this.abscisse_debut = abscisse_debut_;
        this.ordonnee_debut = ordonnee_debut_;
        this.abscisse_fin = abscisse_fin_;
        this.ordonnee_fin = ordonnee_fin_;
    }
    public void Afficher(){
        System.out.println("[" + abscisse_debut + "," + abscisse_fin + "]" + "a" + "[" + ordonnee_debut + "," + ordonnee_fin + "]");
    }
}
