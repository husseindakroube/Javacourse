// 1.4)

import java.io.* ;


public class LireFichierBinaire{
    public static void main(String[] args)  throws IOException  {
        DataInputStream lecture;
        lecture = new DataInputStream(new FileInputStream(args[0]));

            String  s1 = lecture.readUTF(); 
            int entier = lecture.readInt(); 
            Long longValeur = lecture.readLong(); 
            float f1 = lecture.readFloat(); 
            double d1 = lecture.readDouble(); 
            char char1 = lecture.readChar(); 
            boolean b1 = lecture.readBoolean();  
            String s2 = lecture.readUTF(); 

            System.out.println(s1);
            System.out.println(entier);
            System.out.println(longValeur);
            System.out.println(f1);
            System.out.println(d1);
            System.out.println(char1);
            System.out.println(b1);
            System.out.println(s2);
}
}