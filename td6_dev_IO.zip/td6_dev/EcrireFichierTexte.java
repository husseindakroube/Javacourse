import java.io.*; 
class EcrireFichierTexte { 
  public static void main(String[] argv) throws IOException 
  { 
    PrintWriter ecrivain; 
    int n = 5; 
    ecrivain =  new PrintWriter(new BufferedWriter 
    (new FileWriter(argv[0])),true); 
    ecrivain.println("bonjour, comment cela va-t-il ?"); 
    ecrivain.println("un peu difficile ?"); 
    ecrivain.print("On peut mettre des entiers : "); 
    ecrivain.println(n); 
    ecrivain.print("On peut mettre des instances de Object : "); 
    ecrivain.println(36); 
  
     }}  

//b-1) le resultat avec ecrivain.close():
// bonjour, comment cela va-t-il ?
// un peu difficile ?
// On peut mettre des entiers : 5
// On peut mettre des instances de Object : 36
// sans l appel d ecrivain.close(): fichier vide    
// b-2) En positionant le parametre de auto-flush a true on remarque que sans le ecrivain.close le fichier n est pas vide car si c est défini sur true, il appelle automatiquement la méthode flush() après chaque opération d'écriture et on a plus besoin d appeler ecrivain.close()
